import { Component, AfterViewInit } from '@angular/core';

declare var NeoVis: any;

@Component({
  selector: 'app-location-updated',
  templateUrl: './location-updated.component.html',
  styleUrls: ['./location-updated.component.css']
})
export class LocationUpdatedComponent implements AfterViewInit {

  ngAfterViewInit(): void {
    const config = {
      containerId: "graph",
      neo4j: {
        serverUrl: "neo4j+s://44bb5bca.databases.neo4j.io", // or neo4j+s://<host> if using AuraDB
        serverUser: "neo4j",
        serverPassword: "qeBs7NpBR7LILa5bajN5cDVPT-lCJzwJJyrSwQbYrWg"
      },
      labels: {
        "Router": { caption: "name"},
        "Path": { caption: "name"},
        "GameServer": { caption: "name"},
        "Users": { caption: "name"},
      },
      relationships: {
        "CONNECTED": {caption: true},
        "USING": { caption: true}
      },
      initialCypher: "MATCH (n)-[r]->(m) RETURN n,r,m LIMIT 50"
    };

    const viz = new NeoVis.default(config);
    viz.render();
  }
}
