// import { ComponentFixture, TestBed } from '@angular/core/testing';

// import { LocationUpdatedComponent } from './location-updated.component';

// describe('LocationUpdatedComponent', () => {
//   let component: LocationUpdatedComponent;
//   let fixture: ComponentFixture<LocationUpdatedComponent>;

//   beforeEach(async () => {
//     await TestBed.configureTestingModule({
//       declarations: [ LocationUpdatedComponent ]
//     })
//     .compileComponents();
//   });

//   beforeEach(() => {
//     fixture = TestBed.createComponent(LocationUpdatedComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
